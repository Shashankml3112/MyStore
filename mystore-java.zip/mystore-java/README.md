# MyStore (Spring Boot + Supabase)

Backend: Java 17, Spring Boot 3, Spring Data JPA, PostgreSQL (Supabase).
Frontend: static page in src/main/resources/static/index.html.

## Environment variables
DB_URL       jdbc:postgresql://<host>:5432/postgres?sslmode=require
DB_USER      postgres.<your-project-ref>
DB_PASSWORD  your Supabase database password

## Run locally
export DB_URL=... DB_USER=... DB_PASSWORD=...
mvn spring-boot:run
Open http://localhost:8080

## API
GET  /api/products
POST /api/orders  {"name","phone","address","items":[{"productId":1,"qty":2}]}

package com.mystore;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class StoreController {

    private final ProductRepository products;
    private final OrderRepository orders;

    public StoreController(ProductRepository products, OrderRepository orders) {
        this.products = products;
        this.orders = orders;
    }

    public record Line(@NotNull Long productId, @Min(1) @Max(20) int qty) {}

    public record OrderRequest(
            @NotBlank String name,
            @Pattern(regexp = "\\d{10}") String phone,
            @NotBlank String address,
            @NotEmpty List<@Valid Line> items) {}

    @GetMapping("/products")
    public List<Product> list() {
        return products.findAll();
    }

    @PostMapping("/orders")
    public Map<String, Object> place(@Valid @RequestBody OrderRequest req) {
        int total = 0;
        StringJoiner items = new StringJoiner(",", "[", "]");
        for (Line l : req.items()) {
            // Price comes from the database, never from the browser
            Product p = products.findById(l.productId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown product"));
            total += p.getPrice() * l.qty();
            items.add("{\"productId\":" + p.getId() + ",\"qty\":" + l.qty() + "}");
        }
        String orderNo = "MS" + String.valueOf(System.currentTimeMillis()).substring(7);
        Order saved = orders.save(new Order(orderNo, req.name(), req.phone(), req.address(), total, items.toString()));
        return Map.of("orderNo", saved.getOrderNo(), "total", saved.getTotal());
    }
}

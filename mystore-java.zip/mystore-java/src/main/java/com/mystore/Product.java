package com.mystore;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String category;
    private Integer price;
    private String emoji;

    public Product() {}

    public Product(String name, String category, Integer price, String emoji) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.emoji = emoji;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public Integer getPrice() { return price; }
    public String getEmoji() { return emoji; }
}

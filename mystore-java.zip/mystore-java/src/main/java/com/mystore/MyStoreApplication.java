package com.mystore;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MyStoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyStoreApplication.class, args);
    }

    // Adds sample products the first time the app runs on an empty database
    @Bean
    CommandLineRunner seed(ProductRepository repo) {
        return args -> {
            if (repo.count() > 0) return;
            repo.save(new Product("Cotton Kurta", "Clothing", 899, "👕"));
            repo.save(new Product("Running Shoes", "Footwear", 2499, "👟"));
            repo.save(new Product("Steel Water Bottle", "Home", 549, "🍶"));
            repo.save(new Product("Wireless Earbuds", "Electronics", 1799, "🎧"));
            repo.save(new Product("Backpack 25L", "Bags", 1299, "🎒"));
            repo.save(new Product("Desk Lamp", "Home", 999, "💡"));
            repo.save(new Product("Filter Coffee 500g", "Grocery", 420, "☕"));
            repo.save(new Product("Yoga Mat", "Fitness", 749, "🧘"));
        };
    }
}

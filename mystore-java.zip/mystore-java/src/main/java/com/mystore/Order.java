package com.mystore;

import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String orderNo;
    private String customerName;
    private String phone;
    private String address;
    private Integer total;
    @Column(columnDefinition = "text")
    private String itemsJson;
    private OffsetDateTime createdAt = OffsetDateTime.now();

    public Order() {}

    public Order(String orderNo, String customerName, String phone, String address, Integer total, String itemsJson) {
        this.orderNo = orderNo;
        this.customerName = customerName;
        this.phone = phone;
        this.address = address;
        this.total = total;
        this.itemsJson = itemsJson;
    }

    public Long getId() { return id; }
    public String getOrderNo() { return orderNo; }
    public Integer getTotal() { return total; }
}
